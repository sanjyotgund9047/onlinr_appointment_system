-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql313.epizy.com
-- Generation Time: May 11, 2023 at 05:30 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `epiz_33901283_edoc`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `updationDate` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `updationDate`) VALUES
(1, 'admin@gmail.com', '12345678', '30-10-2022 11:42:05 AM');

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `id` int(11) NOT NULL,
  `doctorSpecialization` varchar(255) DEFAULT NULL,
  `doctorId` int(11) DEFAULT NULL,
  `userId` int(11) DEFAULT NULL,
  `consultancyFees` int(11) DEFAULT NULL,
  `appointmentDate` varchar(255) DEFAULT NULL,
  `appointmentTime` varchar(255) DEFAULT NULL,
  `postingDate` timestamp NULL DEFAULT current_timestamp(),
  `userStatus` int(11) DEFAULT NULL,
  `doctorStatus` int(11) DEFAULT NULL,
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`id`, `doctorSpecialization`, `doctorId`, `userId`, `consultancyFees`, `appointmentDate`, `appointmentTime`, `postingDate`, `userStatus`, `doctorStatus`, `updationDate`) VALUES
(3, 'Orthopedics', 4, 5, 500, '2023-04-01', '10:00 AM', '2023-03-30 16:12:47', 1, 1, NULL),
(4, 'Orthopedics', 4, 4, 500, '2023-04-05', '2:45 PM', '2023-04-01 09:09:29', 1, 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `doctors`
--

CREATE TABLE `doctors` (
  `id` int(11) NOT NULL,
  `specilization` varchar(255) DEFAULT NULL,
  `doctorName` varchar(255) DEFAULT NULL,
  `address` longtext DEFAULT NULL,
  `docFees` varchar(255) DEFAULT NULL,
  `contactno` bigint(11) DEFAULT NULL,
  `docEmail` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `creationDate` timestamp NULL DEFAULT current_timestamp(),
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctors`
--

INSERT INTO `doctors` (`id`, `specilization`, `doctorName`, `address`, `docFees`, `contactno`, `docEmail`, `password`, `creationDate`, `updationDate`) VALUES
(4, 'Orthopedics', 'doctor1', 'pune', '500', 0, 'doctor@gmail.com', '25d55ad283aa400af464c76d713c07ad', '2023-03-30 12:14:01', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `doctorslog`
--

CREATE TABLE `doctorslog` (
  `id` int(11) NOT NULL,
  `uid` int(11) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `userip` binary(16) DEFAULT NULL,
  `loginTime` timestamp NULL DEFAULT current_timestamp(),
  `logout` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctorslog`
--

INSERT INTO `doctorslog` (`id`, `uid`, `username`, `userip`, `loginTime`, `logout`, `status`) VALUES
(27, 4, 'doctor@gmail.com', 0x3130332e3130392e31322e3133370000, '2023-03-30 12:14:29', '30-03-2023 05:47:51 PM', 1),
(28, 4, 'Doctor@gmail.com', 0x3135322e35372e3231322e3934000000, '2023-03-30 12:24:48', NULL, 1),
(29, 4, 'doctor@gmail.com', 0x3130332e3130392e31322e3133370000, '2023-03-30 14:02:12', '30-03-2023 07:35:59 PM', 1),
(30, 4, 'doctor@gmail.com', 0x3130332e3130392e31322e3133370000, '2023-03-30 14:14:34', NULL, 1),
(31, 4, 'doctor@gmail.com', 0x3130332e3130392e31322e3133370000, '2023-03-30 16:14:06', '30-03-2023 09:49:04 PM', 1),
(32, 4, 'Doctor@gmail.com', 0x3135322e35372e3231332e3431000000, '2023-03-31 05:41:20', NULL, 1),
(33, 4, 'doctor@gmail.com', 0x3130332e3130392e31322e3133370000, '2023-04-01 09:11:37', '01-04-2023 02:48:31 PM', 1),
(34, NULL, 'Vaishnavi Manjare ', 0x3135322e35372e3139372e3135340000, '2023-05-02 16:43:20', NULL, 0),
(35, NULL, 'Vaishnavi Manjare ', 0x3135322e35372e3139372e3135340000, '2023-05-02 16:44:05', NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `doctorspecilization`
--

CREATE TABLE `doctorspecilization` (
  `id` int(11) NOT NULL,
  `specilization` varchar(255) DEFAULT NULL,
  `creationDate` timestamp NULL DEFAULT current_timestamp(),
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctorspecilization`
--

INSERT INTO `doctorspecilization` (`id`, `specilization`, `creationDate`, `updationDate`) VALUES
(1, 'Orthopedics', '2022-10-30 18:09:46', NULL),
(2, 'Internal Medicine', '2022-10-30 18:09:57', NULL),
(3, 'Obstetrics and Gynecology', '2022-10-30 18:10:18', NULL),
(4, 'Dermatology', '2022-10-30 18:10:28', NULL),
(5, 'Pediatrics', '2022-10-30 18:10:37', NULL),
(6, 'Radiology', '2022-10-30 18:10:46', NULL),
(7, 'General Surgery', '2022-10-30 18:10:56', NULL),
(8, 'Ophthalmology', '2022-10-30 18:11:03', NULL),
(9, 'Anesthesia', '2022-10-30 18:11:15', NULL),
(10, 'Pathology', '2022-10-30 18:11:22', NULL),
(11, 'ENT', '2022-10-30 18:11:30', NULL),
(12, 'Dental Care', '2022-10-30 18:11:39', NULL),
(13, 'Dermatologists', '2022-10-30 18:12:02', NULL),
(14, 'Endocrinologists', '2022-10-30 18:12:10', NULL),
(15, 'Neurologists', '2022-10-30 18:12:30', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tblcontactus`
--

CREATE TABLE `tblcontactus` (
  `id` int(11) NOT NULL,
  `fullname` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `contactno` bigint(12) DEFAULT NULL,
  `message` mediumtext DEFAULT NULL,
  `PostingDate` timestamp NULL DEFAULT current_timestamp(),
  `AdminRemark` mediumtext DEFAULT NULL,
  `LastupdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `IsRead` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcontactus`
--

INSERT INTO `tblcontactus` (`id`, `fullname`, `email`, `contactno`, `message`, `PostingDate`, `AdminRemark`, `LastupdationDate`, `IsRead`) VALUES
(3, 'xyz', 'xyz@gmail.com', 7028477233, 'xyzabc', '2023-03-30 16:25:08', 'ok', '2023-03-30 16:26:02', 1),
(4, 'Sejal', 'sejalphadtare6@gmail.com', 8830717474, 'Hii', '2023-03-31 04:30:30', NULL, NULL, NULL),
(5, 'sadcub', 'sbag', 0, 'SDAKFGUG\r\n', '2023-04-20 15:43:50', NULL, NULL, NULL),
(6, 'sumedha', 'sumedhamkolhe@gmail.c0m', 9850371593, 'hi', '2023-05-11 04:54:43', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tblmedicalhistory`
--

CREATE TABLE `tblmedicalhistory` (
  `ID` int(10) NOT NULL,
  `PatientID` int(10) DEFAULT NULL,
  `BloodPressure` varchar(200) DEFAULT NULL,
  `BloodSugar` varchar(200) NOT NULL,
  `Weight` varchar(100) DEFAULT NULL,
  `Temperature` varchar(200) DEFAULT NULL,
  `MedicalPres` mediumtext DEFAULT NULL,
  `CreationDate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblmedicalhistory`
--

INSERT INTO `tblmedicalhistory` (`ID`, `PatientID`, `BloodPressure`, `BloodSugar`, `Weight`, `Temperature`, `MedicalPres`, `CreationDate`) VALUES
(2, 2, '65', '100', '80', '32', 'Physically Fit', '2023-04-01 09:14:19');

-- --------------------------------------------------------

--
-- Table structure for table `tblpage`
--

CREATE TABLE `tblpage` (
  `ID` int(10) NOT NULL,
  `PageType` varchar(200) DEFAULT NULL,
  `PageTitle` varchar(200) DEFAULT NULL,
  `PageDescription` mediumtext DEFAULT NULL,
  `Email` varchar(120) DEFAULT NULL,
  `MobileNumber` bigint(10) DEFAULT NULL,
  `UpdationDate` timestamp NULL DEFAULT current_timestamp(),
  `OpenningTime` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tblpage`
--

INSERT INTO `tblpage` (`ID`, `PageType`, `PageTitle`, `PageDescription`, `Email`, `MobileNumber`, `UpdationDate`, `OpenningTime`) VALUES
(1, 'aboutus', 'About Us', '<ul style=\"padding: 0px; margin-right: 0px; margin-bottom: 1.313em; margin-left: 1.655em;\" times=\"\" new=\"\" roman\";=\"\" font-size:=\"\" 14px;=\"\" text-align:=\"\" center;=\"\" background-color:=\"\" rgb(255,=\"\" 246,=\"\" 246);\"=\"\"><li style=\"text-align: left;\"><font color=\"#000000\">The Hospital Management System (HMS) is designed for Any Hospital to replace their existing manual, paper based system. The new system is to control the following information; patient information, room availability, staff and operating room schedules, and patient invoices. These services are to be provided in an efficient, cost effective manner, with the goal of reducing the time and resources currently required for such tasks.</font></li><li style=\"text-align: left;\"><font color=\"#000000\">A significant part of the operation of any hospital involves the acquisition, management and timely retrieval of great volumes of information. This information typically involves; patient personal information and medical history, staff information, room and ward scheduling, staff scheduling, operating theater scheduling and various facilities waiting lists. All of this information must be managed in an efficient and cost wise fashion so that an institution\'s resources may be effectively utilized HMS will automate the management of the hospital making it more efficient and error free. It aims at standardizing data, consolidating data ensuring data integrity and reducing inconsistencies.&nbsp;</font></li></ul>', NULL, NULL, '2020-05-20 07:21:52', NULL),
(2, 'contactus', 'Project Developed By:-', '<font size=\"3\" face=\"arial\"><span style=\"text-align: center; text-indent: 179.5pt;\" times=\"\" new=\"\" roman\";=\"\" font-size:=\"\" 14pt;\"=\"\">Mr</span><span style=\"text-align: center; text-indent: 179.5pt;\" times=\"\" new=\"\" roman\";=\"\" font-size:=\"\" 14pt;\"=\"\">s</span><span style=\"text-align: center; text-indent: 179.5pt;\" times=\"\" new=\"\" roman\";=\"\" font-size:=\"\" 14pt;\"=\"\">.</span><span style=\"text-align: center; text-indent: 179.5pt;\" times=\"\" new=\"\" roman\";=\"\" font-size:=\"\" 14pt;\"=\"\">&nbsp;Sejal Bhausaheb Phadtare</span></font><div><font size=\"3\" face=\"arial\"><span style=\"text-align: center; text-indent: 179.5pt; font-family: \" times=\"\" new=\"\" roman\";=\"\" font-size:=\"\" 14pt;\"=\"\">Mr</span><span style=\"text-align: center; text-indent: 179.5pt; font-family: \" times=\"\" new=\"\" roman\";=\"\" font-size:=\"\" 14pt;\"=\"\">s</span><span style=\"text-align: center; text-indent: 179.5pt; font-family: \" times=\"\" new=\"\" roman\";=\"\" font-size:=\"\" 14pt;\"=\"\">.</span><span style=\"text-align: center; text-indent: 179.5pt; font-family: \" times=\"\" new=\"\" roman\";=\"\" letter-spacing:=\"\" -0.1pt;=\"\" font-size:=\"\" 14pt;\"=\"\">&nbsp;</span><span style=\"text-align: center; text-indent: 179.5pt; font-family: \" times=\"\" new=\"\" roman\";=\"\" letter-spacing:=\"\" -0.1pt;=\"\" font-size:=\"\" 14pt;\"=\"\">Vaishnavi Suresh Manjare</span></font></div><div><font size=\"3\" face=\"arial\"><span style=\"text-align: center; text-indent: 179.5pt; font-family: \" times=\"\" new=\"\" roman\";=\"\" font-size:=\"\" 14pt;\"=\"\">Mr.</span><span style=\"text-align: center; text-indent: 179.5pt; font-family: \" times=\"\" new=\"\" roman\";=\"\" letter-spacing:=\"\" -0.1pt;=\"\" font-size:=\"\" 14pt;\"=\"\">&nbsp;</span></font><span style=\"text-align: center; text-indent: 179.5pt;\"><font style=\"\" size=\"3\" face=\"arial\"><span style=\"letter-spacing: -0.1pt;\">Avinash Chandrakant Veer</span></font><br><br><font face=\"Times New Roman\"><span style=\"letter-spacing: -0.133333px;\"><b style=\"\"><font size=\"5\">Project Guide :-<br></font></b><br><span style=\"font-size: 18.6667px;\">&nbsp;Prof. Bhumkar S.M</span></span></font><br></span></div>', 'srcoe@gmail.com', 0, '2020-05-20 07:24:07', '9 am To 8 Pm');

-- --------------------------------------------------------

--
-- Table structure for table `tblpatient`
--

CREATE TABLE `tblpatient` (
  `ID` int(10) NOT NULL,
  `Docid` int(10) DEFAULT NULL,
  `PatientName` varchar(200) DEFAULT NULL,
  `PatientContno` bigint(10) DEFAULT NULL,
  `PatientEmail` varchar(200) DEFAULT NULL,
  `PatientGender` varchar(50) DEFAULT NULL,
  `PatientAdd` mediumtext DEFAULT NULL,
  `PatientAge` int(10) DEFAULT NULL,
  `PatientMedhis` mediumtext DEFAULT NULL,
  `CreationDate` timestamp NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblpatient`
--

INSERT INTO `tblpatient` (`ID`, `Docid`, `PatientName`, `PatientContno`, `PatientEmail`, `PatientGender`, `PatientAdd`, `PatientAge`, `PatientMedhis`, `CreationDate`, `UpdationDate`) VALUES
(2, 4, 'abc', 0, 'abc@gmail.com', 'Male', 'pune', 25, 'corona', '2023-03-30 16:15:22', '2023-04-01 09:13:30'),
(3, 4, 'patient', 0, 'patient@gmail.com', 'Male', 'pune', 23, 'corona', '2023-04-01 09:13:20', '2023-04-01 09:13:37');

-- --------------------------------------------------------

--
-- Table structure for table `userlog`
--

CREATE TABLE `userlog` (
  `id` int(11) NOT NULL,
  `uid` int(11) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `userip` binary(16) DEFAULT NULL,
  `loginTime` timestamp NULL DEFAULT current_timestamp(),
  `logout` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userlog`
--

INSERT INTO `userlog` (`id`, `uid`, `username`, `userip`, `loginTime`, `logout`, `status`) VALUES
(8, NULL, 'patient@gmail.com', 0x3130332e3130392e31322e3133370000, '2023-03-30 12:14:57', NULL, 0),
(9, NULL, 'patient@gmail.com', 0x3130332e3130392e31322e3133370000, '2023-03-30 12:15:18', NULL, 0),
(10, 4, 'patient@gmail.com', 0x3130332e3130392e31322e3133370000, '2023-03-30 12:17:23', NULL, 1),
(11, 4, 'Patient@gmail.com', 0x3135322e35372e3231322e3934000000, '2023-03-30 12:23:07', '30-03-2023 06:22:47 PM', 1),
(12, 4, 'patient@gmail.com', 0x3130332e3130392e31322e3133370000, '2023-03-30 13:32:37', NULL, 1),
(13, 4, 'Patient@gmail.com', 0x3135322e35372e3233372e3930000000, '2023-03-30 13:44:51', '30-03-2023 07:35:10 PM', 1),
(14, 5, 'abc@gmail.com', 0x3130332e3130392e31322e3133370000, '2023-03-30 16:11:08', '30-03-2023 09:46:56 PM', 1),
(15, 4, 'Patient@gmail.com', 0x3135322e35372e3139382e3137390000, '2023-03-31 04:27:07', NULL, 1),
(16, 4, 'patient@gmail.com', 0x3130332e39372e3136342e3433000000, '2023-03-31 06:40:35', NULL, 1),
(17, 4, 'patient@gmail.com', 0x3130332e3130392e31322e3133370000, '2023-04-01 09:07:53', '01-04-2023 02:44:39 PM', 1),
(18, 6, 'surajshinde6742@gmail.com', 0x3135322e35372e3230342e3631000000, '2023-05-11 09:21:03', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `address` longtext DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `regDate` timestamp NULL DEFAULT current_timestamp(),
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fullName`, `address`, `city`, `gender`, `email`, `password`, `regDate`, `updationDate`) VALUES
(4, 'patient1', 'srcoe ', 'pune', 'male', 'patient@gmail.com', '25d55ad283aa400af464c76d713c07ad', '2023-03-30 12:17:04', NULL),
(5, 'abc', 'pune', 'pune', 'male', 'abc@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '2023-03-30 16:10:48', NULL),
(6, 'Suraj Shinde', 'Lonikand', 'Pune', 'male', 'surajshinde6742@gmail.com', '226fd11c2196804e62bd63dcb0ae1f9a', '2023-05-11 09:20:15', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctors`
--
ALTER TABLE `doctors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctorslog`
--
ALTER TABLE `doctorslog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctorspecilization`
--
ALTER TABLE `doctorspecilization`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblcontactus`
--
ALTER TABLE `tblcontactus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblmedicalhistory`
--
ALTER TABLE `tblmedicalhistory`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblpage`
--
ALTER TABLE `tblpage`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblpatient`
--
ALTER TABLE `tblpatient`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `userlog`
--
ALTER TABLE `userlog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `doctors`
--
ALTER TABLE `doctors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `doctorslog`
--
ALTER TABLE `doctorslog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `doctorspecilization`
--
ALTER TABLE `doctorspecilization`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `tblcontactus`
--
ALTER TABLE `tblcontactus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tblmedicalhistory`
--
ALTER TABLE `tblmedicalhistory`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tblpage`
--
ALTER TABLE `tblpage`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tblpatient`
--
ALTER TABLE `tblpatient`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `userlog`
--
ALTER TABLE `userlog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
