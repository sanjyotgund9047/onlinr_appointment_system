<?php
define('DB_SERVER','sql313.epizy.com');
define('DB_USER','epiz_33901283');
define('DB_PASS' ,'78oCpkAlhn4lj');
define('DB_NAME', 'epiz_33901283_edoc');
$con = mysqli_connect(DB_SERVER,DB_USER,DB_PASS,DB_NAME);
// Check connection
if (mysqli_connect_errno())
{
 echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
?>