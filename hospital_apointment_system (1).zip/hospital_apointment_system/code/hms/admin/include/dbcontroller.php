<?php
$DB_host = "sql313.epizy.com";
$DB_user = "epiz_33901283";
$DB_pass = "78oCpkAlhn4lj";
$DB_name = "epiz_33901283_edoc";
try
{
 $DB_con = new PDO("mysql:host={$DB_host};dbname={$DB_name}",$DB_user,$DB_pass);
 $DB_con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(PDOException $e)
{
 $e->getMessage();
}
?>